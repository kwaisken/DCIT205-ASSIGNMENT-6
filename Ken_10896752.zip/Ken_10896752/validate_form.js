function validateform(){
    
    if (usernames.value === '' || usernames.value === null) {
    messages.push("Entry can't be empty!")
  }
  else{
    alert("Entry approved!")
  }
  if (messages.length > 0){
    e.preventDefault()
    errorElement.innerText = messages.join(', ')
  }
  if (usernames.length > 50) {
    messages.push("Excess character length!")
  }
  else{
    alert("Good feedback on your health!")
  }
  if  (c_meds == "no"){
    textarea == null
  }
  if(address.length > 300){
    messages.push("Excess character length!")
  }
  else{
    alert("Location verified!")
  }
}